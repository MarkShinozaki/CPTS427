# Author: Mark Shinozaki
# Date: 4/07/2024
# Cpts 427 - Passwords 

import pandas as pd
from itertools import product
import hashlib

# Load the word list for potential passwords
password_list = pd.read_csv("wordList.txt")
potential_passwords = password_list[password_list.columns[0]].tolist()

# Load the same word list for potential salts
salt_list = pd.read_csv("wordList.txt")
potential_salts = salt_list[salt_list.columns[0]].tolist()

# Load the set of existing hashed passwords
hashed_password_data = pd.read_csv("password.txt")
hashed_password_set = set(hashed_password_data[hashed_password_data.columns[4]].tolist())


# All combinations of potential passwords and salts
password_salt_combinations = list(product(potential_passwords, potential_salts))
found_combinations = []

# Iterate each combination, hash it, and check against the set of known hashes
for combo in password_salt_combinations:
    combined_pw_salt = str(combo[0]) + str(combo[1])
    encoded_combo = combined_pw_salt.encode()

    hasher = hashlib.md5()
    hasher.update(encoded_combo)
    result_hash = hasher.hexdigest()

    combo_with_hash = tuple(list(combo) + [result_hash])

    if result_hash in hashed_password_set:
        found_combinations.append(combo_with_hash)

print(found_combinations)


result_df = pd.DataFrame(found_combinations, columns=['Password', 'Salt', 'MD5 Hash'])
result_df.to_csv("output_refactored.csv", index=False)
